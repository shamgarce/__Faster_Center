<?php
$myconfig['app']='Version 2.3.2';