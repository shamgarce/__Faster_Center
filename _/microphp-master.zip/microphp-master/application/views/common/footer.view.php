<?php if (!defined('IN_WONIU_APP')) {
    exit('No direct script access allowed');
}?>
<hr style="border-bottom-color:gray;border-style:dashed;border-width: 0 0 2px 0;"/>
<p style="text-align: center;">
    <a href="http://microphp.us/plugins/microphp.php?manual.index" target="_blank">参考手册</a>
    | <a href="http://microphp.us/plugins/microphp.php?in.action/8" target="_blank">快速入门</a>
    | <a href="?demo/">HMVC</a>
</p>
<p style="text-align: center;"><?php echo $msg;?></p>
</body>
</html>