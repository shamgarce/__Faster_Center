// public api interface
flowchart.parse = parse;