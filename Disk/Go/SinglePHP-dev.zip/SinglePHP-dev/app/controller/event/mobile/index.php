<?php
namespace Controller\Event\Mobile;
class Index extends \Single\Controller {
    public function _run() {
        echo "这是手机落地页面";
    }
}
