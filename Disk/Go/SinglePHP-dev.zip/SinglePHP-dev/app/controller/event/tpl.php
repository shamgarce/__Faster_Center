<?php
namespace Controller\Event
{
    class Tpl extends \Single\Controller
    {
        public function run()
        {
            $this->display();
        }
    }
}
