<?php
/**
 * Created by PhpStorm
 * @desc: base控制器
 * @package: base.php
 * @author: leandre
 * @copyright: copyright(2014)
 * @version: 14/10/27
 */

namespace Controller;
use Single\Controller;

class Base extends Controller
{
    protected function _init()
    {
    }
}
