<?php
namespace Controller\Inter;
{
    interface Test
    {
        public function add();

        public function del();

        public function modify();
    }
}
